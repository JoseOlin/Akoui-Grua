tarjeta=esp32dev
IDE=qtcreator
platformio project init --ide $IDE --board $tarjeta


#ifndef CONFIG_H
#define CONFIG_H

#define commActiva 1  // Activa o desactiva la comunicación Wifi.
#define commTcpActiva 1
#define commHttpActiva 0
#define commVerbose 1
#define DEVMODE 1

#define ACTIVE_ON_HIGH 0

#define CASA 1

#endif // CONFIG_H
